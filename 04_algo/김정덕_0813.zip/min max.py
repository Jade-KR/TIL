import sys
sys.stdin = open("min max.txt")

T = int(input())

for test in range(1, T + 1):
    n = int(input())
    a = list(map(int, input().split()))
    for i in range(len(a) - 1, 0, -1):
        for j in range(0, i):
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]

    print('#{} {}'.format(test, a[-1] - a[0]))