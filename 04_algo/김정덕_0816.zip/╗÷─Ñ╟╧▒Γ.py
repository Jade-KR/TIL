import sys
sys.stdin = open('색칠하기.txt')
# 2,2  에서 4,4 까지 1번 색상이다
# 누적해서 집어넣어 겹치는 부분 확인

T = int(input())
for tc in range(1, T+1):
    num = int(input())
    list_red = []
    list_blue = []
    cnt = 0
    for _ in range(num):
        square = list(map(int, input().split()))
        f_red = []
        f_blue = []

        for i in range(square[0], square[2]+1):
            for j in range(square[1], square[3]+1):
                if square[-1] == 1:
                    if not [i, j] in list_red:
                        list_red.append([i, j])
                if square[-1] == 2:
                    if not [i, j] in list_blue:
                        list_blue.append([i, j])

    for i in list_red:
        if i in list_blue:
            cnt += 1
    print('#{} {}'.format(tc, cnt))

