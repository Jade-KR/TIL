import sys
sys.stdin = open('부분집합의합.txt')

T = int(input())
for tc in range(1, T+1):
    N, K = map(int, input().split())
    cnt = 0

    arr = [i for i in range(1, 13)]
    for i in range(1, 1 << len(arr)):
        tmp = []
        sum=0
        cnt2=0
        for j in range(len(arr)):
            if i & (1 << j):
               # tmp.append(arr[j])
                sum += arr[j]
                cnt2 += 1
        if sum ==K and cnt2 == N:
            cnt += 1
        #
        # if len(tmp) == N:
        #     sum_t = 0
        #     for k in tmp:
        #         sum_t += k
        #
        #     if sum_t == K:
        #         cnt += 1
    print('#{} {}'.format(tc, cnt))
