import sys
sys.stdin = open("특별한정렬.txt")

T = int(input())
for tc in range(1, T+1):
    N = int(input())
    num = list(map(int, input().split()))
    s_num = []

    for i in range(0, len(num)-1):
        max_n = i
        min_n = i
        if i % 2 == 0:
            for j in range(i + 1, len(num)):
                if num[max_n] < num[j]:
                    max_n = j
            num[i], num[max_n] = num[max_n], num[i]
        if i % 2 == 1:
            for j in range(i + 1, len(num)):
                if num[min_n] > num[j]:
                    min_n = j
            num[i], num[min_n] = num[min_n], num[i]
    print('#{}'.format(tc), end=" ")
    for i in num[0:10]:
        print(i, end=" ")
    print()